import streamlit as st
st.title('Neighborhood insights')
st.write('Coming soon')