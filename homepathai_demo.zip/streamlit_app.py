import streamlit as st

st.set_page_config(page_title="HomePathAI", layout="wide")

st.markdown("""
<style>
#MainMenu {visibility: hidden;}
footer {visibility: hidden;}
header {visibility: hidden;}
.top-nav {display:flex;gap:12px;margin-bottom:25px;}
.nav-btn {padding:10px 16px;background:#e2f3f5;color:#0b3d47;border-radius:8px;text-decoration:none;font-weight:500;}
.nav-btn:hover{background:#b6e3e9;}
</style>
""", unsafe_allow_html=True)

st.markdown("""
<div class="top-nav">
<a class="nav-btn" href="/">Home</a>
<a class="nav-btn" href="/First_Time_Buyer">First-time buyer friendly</a>
<a class="nav-btn" href="/Investor_Analysis">Investor deal analysis</a>
<a class="nav-btn" href="/Neighborhood_Insights">Neighborhood insights</a>
<a class="nav-btn" href="/Repair_Estimator">Repair estimator</a>
<a class="nav-btn" href="/Rent_and_Moving">Rent & moving tools</a>
</div>
""", unsafe_allow_html=True)

st.markdown("# 🔍 Find your next home with AI that actually thinks like a local.")
st.markdown("HomePathAI analyzes neighborhoods, repairs, and numbers—so you don’t have to guess.")

search = st.text_input("Search city, neighborhood, or ZIP", "")
st.write("Your AI-powered home search companion for smarter buying.")

st.markdown("## 🔥 Trending homes near you")
col1, col2 = st.columns(2)
with col1:
    st.image("https://i.ibb.co/j7H3RJL/house-night.jpg", use_column_width=True)
    st.write("**Neighborhood snapshot**  
Safety score: **78**  
Median home price: **$340,000**")
with col2:
    st.image("https://i.ibb.co/0YPG657/house-night.jpg", use_column_width=True)
    st.write("**$579,900**  
4 bd | 3 ba | 2,580 sq ft  
Downtown, Detroit MI  
Nete score: **88**  
Est. value: **$340,000**  
5-yr growth: **+5.2%**")

st.markdown("## 🗺 Neighborhood snapshot")
st.image("https://i.ibb.co/4tg2m16/heatmap-demo.png", use_column_width=True)

st.markdown("## 🔧 Repair estimator preview")
st.image("https://i.ibb.co/4YP6S57/house-night.jpg", use_column_width=True)
