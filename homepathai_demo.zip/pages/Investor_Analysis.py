import streamlit as st
st.title('Investor deal analysis')
st.write('Coming soon')